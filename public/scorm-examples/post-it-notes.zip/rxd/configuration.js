var RXDConfig = {
    // the entry URL to the content
    contentUrl: "https://vimeo.com/lms/content/189331235/video/1199485096/4f968274e9?scoring_algorithm=quiz&completion_threshold=90&passing_score=80&course_title=The+Accidental+Invention+of+Post-it+Notes&skipping_forward=true&speed=true",

    // value to use as the HTML title for the proxy package
    courseTitle: "The Accidental Invention of Post-it Notes",

    // URL where the RXD files are located and available via http/s
    rxdHostUrl: "https://vimeo.com/assets/rxd",

    // the path to the content API wrapper page, appended to the rxdHostUrl
    // unless it is an absolute http/s URL
    contentApi: "contentAPI.html",

    // URL to fetch pre-launch configuration settings from
    // Leave as an empty string if not using (e.g., "")
    preLaunchConfigurationUrl: ""
};
