var RXDConfig = {
    // the entry URL to the content
    contentUrl: "https://vimeo.com/lms/content/189331235/video/1199830281/78cf9b3677?scoring_algorithm=percentage&completion_threshold=15&passing_score=80&course_title=The+Mpemba+Effect%3A+Hot+Water+Freezes+Faster&skipping_forward=false&speed=false",

    // value to use as the HTML title for the proxy package
    courseTitle: "The Mpemba Effect: Hot Water Freezes Faster",

    // URL where the RXD files are located and available via http/s
    rxdHostUrl: "https://vimeo.com/assets/rxd",

    // the path to the content API wrapper page, appended to the rxdHostUrl
    // unless it is an absolute http/s URL
    contentApi: "contentAPI.html",

    // URL to fetch pre-launch configuration settings from
    // Leave as an empty string if not using (e.g., "")
    preLaunchConfigurationUrl: ""
};
